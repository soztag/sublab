#' str_sentence_case
#' 
#' Format a string in sentence case
#' 
#' @param string character string to transform
#' 
#' Sentance case is ...
#' 
#' @export

str_sentence_case <- function( string ) 
  stop( "Sentence case is not implemented yet.")