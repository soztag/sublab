library(testthat)
test_check('lettercase')

