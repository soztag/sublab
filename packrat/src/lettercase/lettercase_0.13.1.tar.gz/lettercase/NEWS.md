lettercase
====


2016-03-03 : Version 0.13.0 
----
First CRAN Release
- Documentation:
-- Fix docs
-- Update README.md
-- Improve vignettes
- Ready for CRAN release
