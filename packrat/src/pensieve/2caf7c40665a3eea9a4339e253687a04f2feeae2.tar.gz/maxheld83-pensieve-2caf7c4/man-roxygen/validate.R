#' @param validate
#' A logical flag, indicating whether the object will be validated.
#' Defaults to `TRUE`.
#'
#' @family validation helpers
