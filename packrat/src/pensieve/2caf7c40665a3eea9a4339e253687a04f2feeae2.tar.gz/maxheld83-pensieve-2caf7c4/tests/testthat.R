library(testthat)
library(pensieve)

test_check("pensieve")
