library(testthat)
test_check("checkpoint")